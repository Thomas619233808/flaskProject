default_app_config = 'monitor.apps.MonitorConfig'
